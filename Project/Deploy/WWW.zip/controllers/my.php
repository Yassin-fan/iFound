<?php
namespace hsC;
class my{
	public function test(){
		
	/*if (function_exists('mysql_connect')) {
		echo 'Mysql扩展已经安装';
	}*/
	
	/*$db_host="localhost";
	$db_user="root";
	$db_pwd="root";
	$db_name="ifound_lists";
	//连接MySQL数据库
	$link=@mysqli_connect($db_host,$db_user,$db_pwd);
	if(!$link){
		exit("连接MySQL数据库服务器失败！");
	}
	else{
		exit("连接MySQL数据库服务器成功！");
	}*/
	
	/*$db = \hsTool\db::getInstance('lists');
	if(!$db){
		exit("连接MySQL数据库服务器失败！");
	}
	else{
		exit("连接MySQL数据库服务器成功！");
	}*/
	
//	$con = mysqli_connect('localhost', 'root', 'root','ifound');
//	//	$db = mysqli_select_db($con,'ifound');
//	if (mysqli_connect_errno($con)) 
//	{ 
//	    echo "连接 MySQL 失败: " . mysqli_connect_error(); 
//	} 
//	mysqli_query($con,"set names 'utf8'");
//	$res = mysqli_query($con,"SELECT * FROM ifound_lists (info_detail) VALUES ('学生卡')");
//	$row = mysqli_fetch_array($res,MYSQLI_ASSOC);
//	//	var_dump($row);
//	echo($row);
	
}
	
	public function removeArt(){
		//检测是否传入index
        if(empty($_POST['artId'])){exit(jsonCode('error', '未传入index'));}

        // 查询文章
        $db = \hsTool\db::getInstance('lists');
        //php的数据库代码有问题，不能识别主键！！！要做一个第二主键，每次通过随机码的第二主键进行获取
//      exit(jsonCode('ok', $_POST['artId']));
        $art = $db->where('second_index = ?', array($_POST['artId']))->fetch();
        if(empty($art)){exit(jsonCode('error', '未找到对应元组'));}
        // 不是自己的文章不能删除
        if($art['info_openid'] != $_POST['info_openid']){exit(jsonCode('error', 'user error'));}
        // 删除
        $db->where('second_index = ?', array($_POST['artId']))->delete();
        exit(jsonCode('ok', 'ok'));
	}
	
	
	public function arts(){
		$db = \hsTool\db::getInstance('lists');
		$page = empty($_POST['page']) ? 1 : intval($_POST['page']);
		$arts = $db
				->where('info_openid = ?', array($_POST['info_openid']))
				->order('submittime desc')
				->limit(($page - 1) * 10, 10)
				->fetchAll();
		if(empty($arts)){exit(jsonCode('empty', ''));}
		exit(jsonCode('ok', $arts));
	}
	
	public function getlists(){
//		$user = checkUser();
		$db = \hsTool\db::getInstance('lists');
		$page = empty($_POST['page']) ? 1 : intval($_POST['page']);
		$arts = $db
				->where("info_openid = ?", array($_POST['info_openid']))
				->order('info_openid desc')
				->limit(($page - 1) * 10, 10)
				->fetchAll();
		if(empty($arts)){exit(jsonCode('empty', ''));}
		exit(jsonCode('ok', $arts));
	}
	/*public function arts(){
		$user = checkUser();
		$db = \hsTool\db::getInstance('articles');
		$page = empty($_GET['page']) ? 1 : intval($_GET['page']);
		$arts = $db
				->where('art_uid = ?', array($user['u_id']))
				->order('art_id desc')
				->limit(($page - 1) * 10, 10)
				->fetchAll();
		if(empty($arts)){exit(jsonCode('empty', ''));}
		exit(jsonCode('ok', $arts));
	}*/
}