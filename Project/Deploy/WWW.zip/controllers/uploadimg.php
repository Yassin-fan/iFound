<?php
namespace hsC;

class uploadimg{
	
	public function test(){
		echo("test");
	}
	
	
	 public function index(){
	 	
        if(!empty($_FILES['file'])){
            //获取扩展名
            $exename  = $this->getExeName($_FILES['file']['name']);
            if(!in_array($exename, array('png', 'gif', 'jpeg', 'jpg'))){
            	//不是图片，就报错
            	exit(jsonCode('error', 'exename error'));
			}
			//保存在imgs文件夹下随机名字
            $imageSavePath = 'imgs/'.uniqid().'.'.$exename;
            if(move_uploaded_file($_FILES['file']['tmp_name'], $imageSavePath)){

                exit(jsonCode('ok', $imageSavePath));
            }else{
                exit(jsonCode('error', 'upload error 01'));
            }
        }else{
            exit(jsonCode('error', 'upload error 02'));
        }
    }
    
    public function getExeName($fileName){
        $pathinfo      = pathinfo($fileName);
        return strtolower($pathinfo['extension']);
    }
		
}