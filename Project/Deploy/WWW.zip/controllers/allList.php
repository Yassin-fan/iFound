<?php
namespace hsC;
class allList{
	
	public function test(){
		echo("test");
	}
	
	public function updatefind(){
		// 签名验证
		//checkSign();
		//调用模型完成用户登录
        $memberModel = new \hsModel\allList();
        $memberModel->updatefind();
	}
	
	public function getfindlist(){
		// 签名验证
		//checkSign();
		//调用模型完成用户登录
        $memberModel = new \hsModel\allList();
        $memberModel->getfindlist();
	}
	
	public function getlist(){
		// 签名验证
		//checkSign();
		//调用模型完成用户登录
        $memberModel = new \hsModel\allList();
        $memberModel->getlist();
	}
	
	public function thisitem(){
		// 签名验证
		//checkSign();
		//调用模型完成用户登录
        $memberModel = new \hsModel\allList();
        $memberModel->thisitem();
	}
	
	public function search(){
		 $memberModel = new \hsModel\allList();
        $memberModel->search();
	}
}
