<?php
namespace hsC;
class index{
	
	public function index(){
		echo("hello");
		exit(jsonCode('ok', 'api 1.0.1...'));
	}
	
	public function test(){
		exit("hello");
	}
}
