<?php
namespace hsModel;

class allList{
	
	public function search(){
		if(empty($_POST['text'])){exit(jsonCode('error', '未传入关键词'));}
		$db_host="localhost";
		$db_user="root";
		$db_pwd="root";
		$detail = $_POST['text'];
		$brief = $_POST['text'];
		$page = empty($_POST['page']) ? 1 : intval($_POST['page']);
		$min = ($page-1)*10;
		$link=@mysqli_connect($db_host,$db_user,$db_pwd,"ifound");
		if(!$link){
			exit("连接MySQL数据库服务器失败！");
		}
		
		$my_sql = "SELECT * FROM ifound_lists WHERE info_detail like '%$detail%' or info_brief like '%$brief%' ORDER BY submittime DESC LIMIT $min,10";
//		exit(jsonCode('ok', $my_sql));
		mysqli_set_charset($link, "utf8");
		$select_result1 = mysqli_query($link, $my_sql);
		$row = $select_result1 -> fetch_all(MYSQLI_ASSOC);
		if(empty($row)){exit(jsonCode('empty', ''));}
		mysqli_close($link);
		exit(jsonCode('ok', $row));
	}
	
	
	public function getlist(){
//		
//		$db = \hsTool\db::getInstance('lists');
//		$page = empty($_POST['page']) ? 1 : intval($_POST['page']);
//		$arts = $db
//				->where('lostORfind = ? and info_kind = ?', array($_POST['lostORfind'] , $_POST['info_kind']))
//				->order('submittime desc')
//				->limit(($page - 1) * 10, 10)
//				->fetchAll();
//		exit(jsonCode('ok', $arts));
//		if(empty($arts)){exit(jsonCode('empty', ''));}
//		exit(jsonCode('ok', $arts));
//		
		
		$db_host="localhost";
		$db_user="root";
		$db_pwd="root";
		$link=@mysqli_connect($db_host,$db_user,$db_pwd,"ifound");
		if(!$link){
			exit("连接MySQL数据库服务器失败！");
		}
		$lostORfind = $_POST['lostORfind'];
		$info_kind = $_POST['info_kind'];
		$page = empty($_POST['page']) ? 1 : intval($_POST['page']);
		$min = ($page-1)*10;
		if ($lostORfind == "推荐"){
			if ( $info_kind == "全部"){
				$my_sql = "SELECT * FROM ifound_lists ORDER BY submittime DESC LIMIT $min,10";
			}else{
				$my_sql = "SELECT * FROM ifound_lists WHERE info_kind = '$info_kind' ORDER BY submittime DESC LIMIT $min,10";
			}
		}else{
			if ( $info_kind == "全部"){
				$my_sql = "SELECT * FROM ifound_lists WHERE lostORfind = '$lostORfind' ORDER BY submittime DESC LIMIT $min,10";
			}else{
				$my_sql = "SELECT * FROM ifound_lists WHERE lostORfind = '$lostORfind' and info_kind = '$info_kind' ORDER BY submittime DESC LIMIT $min,10";
			}
		}
		
		mysqli_set_charset($link, "utf8");
		$select_sql = "select * from ifound_lists";
		$select_result1 = mysqli_query($link, $my_sql);
		$row = $select_result1 -> fetch_all(MYSQLI_ASSOC);
		if(empty($row)){exit(jsonCode('empty', ''));}
		mysqli_close($link);
		exit(jsonCode('ok', $row));

//		$db = \hsTool\db::getInstance('lists');
//		$this->db->query('select * from ifound_lists where info_kind = ?', array($_POST['info_kind']));
//		$arr = $this->db->queryFetchAll();
//		exit(jsonCode('ok', $arr));
	}

	
	public function thisitem(){
		$db = \hsTool\db::getInstance('lists');
		$art = $db->where('second_index = ?', array($_POST['second_index']))->fetch();
        if(empty($art)){exit(jsonCode('error', '未找到对应元组'));}
        exit(jsonCode('ok', $art));
	}
	
	public function updatefind(){
		$db = \hsTool\db::getInstance('lists');
		$member = array();
			$member['lostORfind'] = $_POST['lostORfind'];
			$member['submittime'] = time();
			$member['info_openid'] = $_POST['info_openid'];
			$member['info_kind'] = $_POST['info_kind'];
			$member['info_detail']   = $_POST['info_detail'];
			$member['info_location'] = $_POST['info_location'];
			$member['info_number'] = $_POST['info_number'];
			$member['info_brief'] = $_POST['info_brief'];
			$member['info_time'] = $_POST['info_time'];
			$member['info_pictures'] = $_POST['info_pictures'];
			$member['second_index'] = uniqid();//用随机码作为隐形序列号
			//因为一添加进去，index才会自增，但是就没办法在此处对刚才插入的元组进行修改，所以没法做index的拷贝，只能用随机码
		$member['index'] =$db->add($member);
		if(!$member['index']){exit(jsonCode('error', '服务器忙请重试'));}
		exit(jsonCode('ok', $member));
	}
	
	
	public function updatelost(){
		$db = \hsTool\db::getInstance('lists');
		$member = array();
			$member['lostORfind'] = $_POST['lostORfind'];
			$member['submittime'] = time();
			$member['info_openid'] = $_POST['info_openid'];
			$member['info_kind'] = $_POST['info_kind'];
			$member['info_detail']   = $_POST['info_detail'];
			$member['info_location'] = $_POST['info_location'];
			$member['info_number'] = $_POST['info_number'];
			$member['info_brief'] = $_POST['info_brief'];
			$member['info_time'] = $_POST['info_time'];
			$member['info_pictures'] = $_POST['info_pictures'];
			$member['second_index'] = uniqid();//用随机码作为隐形序列号
			//因为一添加进去，index才会自增，但是就没办法在此处对刚才插入的元组进行修改，所以没法做index的拷贝，只能用随机码
		$member['index'] =$db->add($member);
		if(!$member['index']){exit(jsonCode('error', '服务器忙请重试'));}
		exit(jsonCode('ok', $member));
	}
}
	

