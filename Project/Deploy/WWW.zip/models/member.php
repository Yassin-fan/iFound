<?php
namespace hsModel;

class member{
	
	public function login(){
		
		// 查询用户是否已经注册
		$db = \hsTool\db::getInstance('members');
		$member = $db->where('u_openid = ?', array($_POST['openid']))->fetch();
		
		// 用户未注册,返回wrongopenid状态
		if(empty($member)){
			exit(jsonCode('wrongopenid', '用户未注册'));
		}
		
		//非空
		if($member['u_password'] != $_POST['password']){
			exit(jsonCode('wrongpass', '密码错误'));
		}
		
		// 如果用户已经注册 member 变量中已经保存用户信息
		// 返回用户信息
		exit(jsonCode('ok', $member));
	}
	
	
	public function reg(){
		
		// 查询用户是否已经注册
		$db = \hsTool\db::getInstance('members');
		$member = $db->where('u_openid = ?', array($_POST['openid']))->fetch();
		// 用户未注册
		if(empty($member)){
			$member = array();
			$member['u_openid'] = $_POST['openid'];
			$member['u_email'] = $_POST['email'];
			$member['u_password']   = $_POST['password'];
			$member['u_random'] = uniqid();
			$member['u_regtime']= time();
			$member['u_id']     = $db->add($member);
			exit(jsonCode('ok', $member));
		}
		//添加主键失败，要返回注册失败
		if( empty($member['u_id']) && !empty($member['u_openid']) ){
			$member = array();
			$member['u_openid'] = '';
			$member['u_email'] = '';
			$member['u_password']   = '';
			$member['u_random'] = '';
			$member['u_regtime']= '';
			$member['u_id']     = '';
			exit(jsonCode('error', '注册失败，请返回重试'));
		}
		// 如果用户已经注册 member 变量中已经保存用户信息
		// 返回用户信息
		exit(jsonCode('exist', ''));
	}
	
}